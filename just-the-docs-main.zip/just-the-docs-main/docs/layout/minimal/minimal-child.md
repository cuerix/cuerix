---
title: Minimal layout child page
layout: minimal
parent: A minimal layout page
grand_parent: Layout
---

# Minimal layout child page

This is a child page that uses the same minimal layout as its parent page.
